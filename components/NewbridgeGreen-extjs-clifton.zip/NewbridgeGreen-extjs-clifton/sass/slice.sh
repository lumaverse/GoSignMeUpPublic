sencha slice theme -d ../../extjs -m manifest.js -c ../css/clifton.css -o ../themes/images/default/ -v
sencha slice theme -d ../../extjs -m manifest.js -c ../css/clifton-yellow.css -o ../themes/images/yellow/ -v
sencha slice theme -d ../../extjs -m manifest.js -c ../css/clifton-blue.css -o ../themes/images/blue/ -v
sencha slice theme -d ../../extjs -m manifest.js -c ../css/clifton-green.css -o ../themes/images/green/ -v
sencha slice theme -d ../../extjs -m manifest.js -c ../css/clifton-pink.css -o ../themes/images/pink/ -v
