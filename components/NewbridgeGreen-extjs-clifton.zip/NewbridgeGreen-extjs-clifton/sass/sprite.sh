compass sprite --force "default/icon/*.png" -f sprites/_grey.sass
compass sprite --force "blue/icon/*.png" -f sprites/_blue.sass
compass sprite --force "green/icon/*.png" -f sprites/_green.sass
compass sprite --force "yellow/icon/*.png" -f sprites/_yellow.sass
compass sprite --force "pink/icon/*.png" -f sprites/_pink.sass
